#include <iostream>
#include "image.h"


int main()
{

////AUFGABENTEIL (b) (c)////
    Image image1(4, 3);
    
    for (unsigned int y = 0; y < image1.height(); y++)
    {
        for (unsigned int x = 0; x < image1.width(); x++)
        {
            if ( (x+y) % 2 == 1) image1(x, y) = 255;
        }
    }   
    std::cout << to_string(image1) << std::endl;
/////////////////////////////
////  AUFGABENTEIL (d)   ////
    writePGM(image1, "board4x3.pgm");

    Image image2 = readPGM("board4x3.pgm");

    std::cout << to_string(image2);

    std::cout << "Compare both images image1 and image2: " << (image1 == image2) << std::endl << std::endl;
/////////////////////////////

////  AUFGABENTEIL (e)   ////
    Image chess43 = chessboard(4, 3, 1);
    std::cout << to_string(chess43);
    std::cout << "Compare both images image1 and image43: " << (image1 == chess43) << std::endl;
/////////////////////////////


////  AUFGABENTEIL (f)   ////
    Image chess400300 = chessboard(400, 300, 20);
    writePGM(chess400300, "board400x300.pgm");

    Image chess400300_read = readPGM("board400x300.pgm");
    std::cout << "Compare both chessboards: " << (chess400300 == chess400300_read) << std::endl;
/////////////////////////////

////  AUFGABENTEIL (g)   ////
    Image chess400300_inverse = invert_image(chess400300);
    writePGM(chess400300_inverse, "board400x300-inverse.pgm");
/////////////////////////////


////  AUFGABENTEIL (h)   ////
    Image christmas = readPGM("christmas.pgm");
    Image christmas_inverse = invert_image(christmas);
    writePGM(christmas_inverse, "christmas-inverse.pgm");
/////////////////////////////

    return 0;
}